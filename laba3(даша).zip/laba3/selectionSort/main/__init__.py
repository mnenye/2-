import random


def randomDataSort():
    number = [random.randint(-100, 300) for x in range(random.randint(2, 10))] #Создание массива размером от 2 до 10,
    # включающим в себя числа от -100 до 300
    word = ''
    for i in number:
        word += str(i) + ' ' #С помощью цикла for каждое число из массива number преобразуется в строку, и все
        # числа объединяются в одну строку с пробелами между ними.
    return word #  - Функция возвращает строку, состоящую из случайных чисел.

def dataSort(data): #Прием данных: Функция принимает строку data, в которой находятся числа, разделенные пробелами.
    number = [] #Создается пустой список number.
    for x in data.split(): #С помощью цикла for строка разбивается на отдельные элементы, и для каждого
        # элемента проверяется, является ли он числом (целым или отрицательным).

        if x.isdigit() or (x[0] == '-' and x[1::].isdigit()): # Если элемент – число, оно добавляется в список number.
            number.append(int(x))
        else: #Если элемент не число, функция возвращает пустую строку.
            return ''
    number = sorted(number) #Полученный список number сортируется.
    word = ''
    for i in number:
        word += str(i) + ' ' # - Как и в первой функции, числа снова объединяются в строку с пробелами.
    return word

# для сортировки по убыванию

def dataSortReverse(data):
    num = []
    for x in data.split():
        if x.isdigit() or (x[0] == '-' and x[1::].isdigit()):
            num.append(int(x))
        else:
            return ''
    num = sorted(num, reverse=True)  # Сортировка по убыванию
    word = ''
    for i in num:
        word += str(i) + ' '
    return word