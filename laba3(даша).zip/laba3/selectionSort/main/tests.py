import time
from .models import Data
from random import randint
from .__init__ import dataSort

def testAdd100(): #Цель def - добавление 100 массивов
    start_time = time.time() # Здесь устанавливается начальное время выполнения кода, что позволит позже вычислить, сколько времени ушло на выполнение.
    test_success = True # test_success указывает, что тест прошел успешно, а textt содержит сообщение о результате теста.
    textt = 'Тест прошел успешно'
    for i in range(100): # - Внешний цикл повторяется 100 раз.
        oo = '' # - Внутренний цикл создает строку oo, в которую добавляются случайные числа. Количество чисел варьируется от 2 до 10 (включительно).
        for i in range(randint(2, 10)): #- Каждое случайное число (от -100 до 100) превращается в строку и добавляется к oo.
            i = randint(-100, 100)
            oo += str(i) + ' '
        Data(oldData= oo).save() # - После этого создается объект Data, в который сохраняется сгенерированная строка oo.
    finish_time = time.time() - start_time #Здесь вычисляется общее время выполнения кода с начала, когда было зафиксировано start_time.
    test_dictionary = { #В словарь test_dictionary помещаются результаты теста: сообщение, статус и время выполнения, которое преобразуется в строку.
        'textt': textt,
        'test_success': test_success,
        'finish_time': str(finish_time)
    }
    if test_dictionary['test_success']: # - Если test_success истинно, выводятся результаты теста, включая время выполнения
        print("Тест для 100 массивов: " + test_dictionary['textt']) # Также происходит выгрузка данных, сохраненных в модели Data.
        print("Время выполнения: " + test_dictionary['finish_time'] + "\n")
        print("Выгрузка массивов: ")
        last_id = Data.objects.last().id #Сначала определяются идентификаторы первого и последнего объекта, затем происходит цикл от первого до последнего.
        first_id = Data.objects.first().id
        for i in range(first_id, last_id + 1):
            o_data = (list(Data.objects.filter(id=i).values_list('oldData', flat=True)))[0] #Для каждого объекта извлекается поле oldData, и оно выводится на экран вместе с его порядковым номером.
            print(str(i - first_id) + ". " + o_data)
    else:
        print("Тест для 100 массивов: " + test_dictionary['textt']) #Если тест не прошел, выводится сообщение об этом.

def testAdd1000():
    start_time = time.time()
    test_success = True
    textt = 'Тест прошел успешно'
    for i in range(1000):
        oo = ''
        for i in range(randint(2, 10)):
            i = randint(-100, 100)
            oo += str(i) + ' '
        Data(old_data=oo).save()
    finish_time = time.time() - start_time
    test_dictionary = {
        'textt': textt,
        'test_success': test_success,
        'finish_time': str(finish_time)
    }
    if test_dictionary['test_success']:
        print("Тест для 1000 массивов: " + test_dictionary['textt'])
        print("Время выполнения: " + test_dictionary['finish_time'] + "\n")
        print("Выгрузка массивов: ")
        last_id = Data.objects.last().id
        first_id = Data.objects.first().id
        for i in range(first_id, last_id + 1):
            o_data = (list(Data.objects.filter(id=i).values_list('oldData', flat=True)))[0]
            print(str(i - first_id) + ". " + o_data)
    else:
        print("Тест для 1000 массивов: " + test_dictionary['textt'])

def testAdd10000():
    start_time = time.time()
    test_success = True
    textt = 'Тест прошел успешно'
    for i in range(10000):
        oo = str(randint(-100, 100)) + ' ' + str(randint(-100, 100)) + ' ' + str(randint(-100, 100)) + ' ' + str(randint(-100, 100)) + ' ' + str(randint(-100, 100)) + ' ' + str(randint(-100, 100)) + ' ' + str(randint(-100, 100))
        Data(oldData=oo).save()
    finish_time = time.time() - start_time
    test_dictionary = {
        'textt': textt,
        'test_success': test_success,
        'finish_time': str(finish_time)
    }

def testSort100():

    n = 0 #счетчик для отслеживания успешности сортировки.
    start_time = time.time() #фиксируем текущее время для определения времени выполнения кода.
    test_success = True # флаг, указывающий на успешность теста.
    textt = 'Тест прошел успешно' #сообщение о результате тестирования.
    count = 0 #счетчик для хранения количества пустых данных.

    if Data.objects.last(): #Проверяется, есть ли данные в базе.

        last_id =  Data.objects.last().id #`first_id` и `last_id` определяются
        # как идентификаторы первого и последовательно последнего объекта в базе данныx
        first_id = Data.objects.first().id
    else:
        test_success = False #Если данных нет, устанавливается флаг `test_success` в `False`,
        test_dictionary = { #и создается словарь с сообщением, что нечего сортировать.
            'textt': 'Нечего сортировать',
            'test_success': test_success,
            'finish_time': 0
        }


    for i in range(first_id, last_id + 1): #  В этом цикле происходит перебор всех объектов от `first_id` до `last_id`.
        data = (list(Data.objects.filter(id=i).values_list('sortData', flat=True)))[0] #Для каждого объекта проверяется значение `sortData`.
        if data == '':
            count+=1 #Если оно пустое, увеличивается счетчик `count`.
    if count == 0:
        test_success = False #Если все объекты содержат заполненные значения `sortData`,
        # флаг `test_success` остается `True`, иначе он устанавливается на `False`.
        test_dictionary = {
            'textt' : 'Нечего сортировать',
            'test_success': test_success,
            'finish_time': 0
        }


    if (last_id - first_id) + 1 < 100: #  Здесь определяется диапазон,
        # в котором будет происходить сортировка. Если общее количество
        # объектов меньше 100, используется полное количество объектов,

        rang = (last_id - first_id) + 1
    else:
        # иначе используется максимальное значение 100.
        rang = 100
    for i in range(rang):
        #Здесь происходит основной процесс сортировки.
        # Для каждой итерации происходит следующее:
        while True:
            r_id = randint(first_id, last_id) #Генерируется случайный идентификатор `r_id`.
            data = (list(Data.objects.filter(id=r_id).values_list('sortData', flat=True)))[0]
            #Извлекается `sortData`. Цикл продолжается до тех пор,
            # пока не будет найден объект с пустым `sortData`.
            if data == '':
                break
        old_data_ofdata = (list(Data.objects.filter(id=r_id).values_list('oldData', flat=True)))[0]
        #Если `data` пусто, выполняется сортировка старых
        # данных посредством функции `dataSort`, создается новый объект `Data`
        # с обновленными полями `sortData` и `oldData`, и сохраняется в базу.

        if data == '':
            ss = dataSort(old_data_ofdata)
            dd = Data(id= r_id)
            dd.sortData = ss
            dd.oldData = old_data_ofdata
            dd.save()
            n += 1
            #Увеличивается счетчик `n`, который отслеживает
            # количество успешно обработанных объектов.

    if n != rang:
        #Если количество обработанных элементов не равно `rang`,
        # флаг успеха устанавливается в `False`, и текст сообщения
        # обновляется на "Ошибка теста".
        n = 0
        test_success = False
        textt = 'Ошибка теста'
    finish_time = time.time() - start_time

    #Время выполнения и формирование итогового словаря:
    test_dictionary = {
        'textt': textt,
        'test_success': test_success,
        'finish_time': str(finish_time)
    }

    #Вывод результатов тестирования:
    if test_dictionary['test_success']:
        print("Тест cортировки 100 массивов: " + test_dictionary['textt'])
        print("Время выполнения: " + test_dictionary['finish_time'] + "\n")
        print("Выгрузка массивов: ")
        last_id = Data.objects.last().id
        first_id = Data.objects.first().id
        for i in range(first_id, last_id + 1):
            o_data = (list(Data.objects.filter(id=i).values_list('oldData', flat=True)))[0]
            s_data = (list(Data.objects.filter(id=i).values_list('sortData', flat=True)))[0]
            print(str(i - first_id) + ". " + o_data + ", отсорт данные: " + s_data)
    #  В зависимости от успеха теста выводятся соответствующие
    #  сообщения, включая время выполнения и выгрузку
    #  отсортированных данных. Если тест не прошел,
    #  выводится соответствующее сообщение о неудаче.
    else:
        print("Тест сортировки 100 массивов: " + test_dictionary['textt'])

def testClear(): #Функция testClear() предназначена для очистки
    # данных в базе данных, и она содержит следующие шаги:
    start_time = time.time() #Здесь фиксируется текущее время в
    # момент начала выполнения функции. Это необходимо для
    # измерения времени, затраченного на выполнение операции.
    test_success = True #test_success: флаг, который
    # изначально устанавливается в True, предполагая,
    # что тест пройдет успешно.
    textt = 'Тест прошел успешно' #textt: текстовое сообщение,
    # которое будет выводиться в случае успешного завершения
    # теста.
    Data.objects.all().delete()
    #Эта строка удаляет все объекты из модели Data.
    # Это важный шаг, цель которого — очистить все данные из
    # базы. В зависимости от контекста использования,
    # необходимо убедиться, что это действие безопасно и
    # уместно, поскольку оно не может быть отменено.
    finish_time = time.time() - start_time
    # Здесь вычисляется общее время, затраченное на
    # выполнение операции очистки, путем вычитания
    # времени начала из текущего времени.
    test_dictionary = {
        #Создается словарь test_dictionary, который содержит
        # текст сообщения, статус успешности теста и время
        # выполнения в виде строки.
        'textt': textt,
        'test_success': test_success,
        'finish_time': str(finish_time)
    }
    if test_dictionary['test_success']:
        #Здесь происходит вывод результата теста. Поскольку в
        # коде флаг test_success всегда устанавливается в True,
        # часть, связанная с неудачным тестом, в данном случае не
        # будет выполняться.
        #- Если тест прошел успешно, выводится сообщение о том,
        # что тест успешен, и время выполнения.
        print("Тест очистки массивов: " + test_dictionary['textt'])
        print("Время выполнения: " + test_dictionary['finish_time'])
    else:
        print("Тест очистки массивов: " + test_dictionary['textt'])

def f():
    testClear()
    print("---------------тесты для 100 массивов------------------")
    print("\n")
    testAdd100()
    print("\n")
    testSort100()
    print("\n")
    testClear()
    print("---------------тесты для 100 массивов------------------\n")


